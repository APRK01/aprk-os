This is a read-only RAM disk.
